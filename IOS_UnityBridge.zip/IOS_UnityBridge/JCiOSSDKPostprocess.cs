using UnityEditor;
using UnityEditor.Callbacks;
using System.IO;
#if UNITY_IOS || UNITY_IPHONE
using UnityEditor.iOS.Xcode;
using JCiOSSDK.Editor;
#endif

public static class JCiOSSDKPostprocess
{
    /// <summary>
    /// System framework to be added
    /// </summary>
    static string[] systemFrameworks = new string[]
    {
        "Accelerate.framework",
        "AdSupport.framework",
        "AVFoundation.framework",
        "CoreGraphics.framework",
        "CoreLocation.framework",
        "CoreMedia.framework",
        "CoreTelephony.framework",
        "iAd.framework",
        "MessageUI.framework",
        "SafariServices.framework",
        "Security.framework",
        "SystemConfiguration.framework",
        "UIKit.framework",
        "VideoToolbox.framework",
        "WebKit.framework",
    };



    [PostProcessBuild(999)]
    public static void OnPostProcessBuild(BuildTarget buildTarget, string path)
    {

        //#if UNITY_IOS || UNITY_IPHONE
        if (buildTarget == BuildTarget.iOS)
        {
            string pbxprojPath = path + "/Unity-iPhone.xcodeproj/project.pbxproj";

            var pbxProject = new PBXProject();
            pbxProject.ReadFromFile(pbxprojPath);

            //unity 2019 version is available
            //string target = pbxProject.GetUnityMainTargetGuid();

            //unity 2018、2017 version is available
            string target = pbxProject.TargetGuidByName("Unity-iPhone");

            pbxProject.SetBuildProperty(target, "ENABLE_BITCODE", "NO");
            //pbxProject.SetBuildProperty(target, "GCC_ENABLE_OBJC_EXCEPTIONS", "YES");
            //pbxProject.SetBuildProperty(target, "GCC_C_LANGUAGE_STANDARD", "gnu99");

            //set Capability
            AddCapability(pbxProject, target, path);
            // 
            AddSystemFramework(pbxProject, target);
            
            pbxProject.AddBuildProperty(target, "OTHER_LDFLAGS", "-ObjC");
            //pbxProject.AddBuildProperty(target, "OTHER_LDFLAGS", "-fobjc-arc");

            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libbz2.tbd", "Libraries/libbz2.tbd", PBXSourceTree.Sdk));
            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libz.tbd", "Libraries/libz.tbd", PBXSourceTree.Sdk));
            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libxml2.tbd", "Libraries/libxml2.tbd", PBXSourceTree.Sdk));
            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libsqlite3.tbd", "Libraries/libsqlite3.tbd", PBXSourceTree.Sdk));
            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libc++.tbd", "Libraries/libc++.tbd", PBXSourceTree.Sdk));
            pbxProject.AddFileToBuild(target, pbxProject.AddFile("usr/lib/libresolv.9.tbd", "Libraries/libresolv.9.tbd", PBXSourceTree.Sdk));

            pbxProject.WriteToFile(pbxprojPath);

            //Modifying "InfoPlist" Configuration
            EditInfoPlist(path);
        }
        //#endif
    }


    /// <summary>
    /// Modifying InfoPlist
    /// </summary>
    static void EditInfoPlist(string prjPath)
    {
        var plistPath = Path.Combine(prjPath, "Info.plist");
        PlistDocument plist = new PlistDocument();
        plist.ReadFromFile(plistPath);

        //Unity Two changes to be made to project routines
        plist.root.SetBoolean("ITSAppUsesNonExemptEncryption", false);
        string exitsOnSuspendKey = "UIApplicationExitsOnSuspend";
        if (plist.root.values.ContainsKey(exitsOnSuspendKey))
        {
            plist.root.values.Remove(exitsOnSuspendKey);
        }
	
	//Some channels use the Get Location feature internally
	plist.root.SetString("NSLocationWhenInUseUsageDescription", "The app needs to get your location");
        //Google id for admob
        plist.root.SetString("GADApplicationIdentifier", "ca-app-pub-9488501426181082/7319780494");

        plist.root.SetBoolean("GADIsAdManagerApp", true);
        plist.WriteToFile(plistPath);
    }


    /// <summary>
    /// set iOS Capability
    /// </summary>  
    private static void AddCapability(PBXProject pbxProject, string targetGuid, string path)
    {
        var product = pbxProject.GetBuildPropertyForAnyConfig(targetGuid, "PRODUCT_NAME");
        var rentitlementFilePath = $"Unity-iPhone/{product}.entitlements";
        var fullPath = Path.Combine(path, rentitlementFilePath);

        var doc = new PlistDocument();
        doc.root.SetBoolean("com.apple.developer.networking.wifi-info", true);
        doc.WriteToFile(fullPath);

        pbxProject.AddCapability(targetGuid, PBXCapabilityType.AccessWiFiInformation, rentitlementFilePath);
    }



    /// <summary>
    /// add system Framework
    /// </summary>
    static void AddSystemFramework(PBXProject pbxProject, string targetGuid)
    {
        foreach (var framework in systemFrameworks)
        {
            pbxProject.AddFrameworkToProject(targetGuid, framework, false);
        }
    }

}
