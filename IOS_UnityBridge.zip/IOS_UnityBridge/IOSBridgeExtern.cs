using System.Runtime.InteropServices;

namespace IOSAd
{
    //-------------------------------------------------------------------------
    //----------This file is the "IOS Bridge" external interface file----------
    //-------------------------------------------------------------------------

    public partial class IOSBridge
    {        
        //[DllImport("__Internal")]
        //static extern bool initSDKWithC();

        [DllImport("__Internal")]
        static extern bool isReadyIntersitial();

        [DllImport("__Internal")]
        static extern void showIntersitial();

        [DllImport("__Internal")]
        static extern bool isReadyRewardVideo();

        [DllImport("__Internal")]
        static extern void showRewardVideo();

        [DllImport("__Internal")]
        static extern void showBannerView();

        [DllImport("__Internal")]
        static extern void removeBannerView();

        //public static void InitSDK()
        //{
        //    initSDKWithC();
        //}
    }
}
