#define SHOW_IOS_ADSTATE_LOG
using UnityEngine;

namespace IOSAd
{
    //------------------------------------------------------------------
    //----------This file is an "IOS Bridge" call and use file----------
    //------------------------------------------------------------------

    public partial class IOSBridge
    {
        /// <summary>
        /// Intersitial Ad-->is Ready?
        /// </summary>
        public static bool IsIntersitialReady()
        {
            var value = isReadyIntersitial();
#if SHOW_IOS_ADSTATE_LOG
            Debug.Log("-----> IsInterReady:" + value);
#endif
            return value;
        }

        /// <summary>
        /// Intersitial Ad-->show
        /// </summary>
        public static void ShowIntersitial()
        {
            showIntersitial();
        }

        /// <summary>
        /// Intersitial Ad-->if Ready -->show，
        /// </summary>
        public static bool TryShowIntersitial()
        {
            Debug.Log("<-----> TryShowIntersitial");

            var value = isReadyIntersitial();
            Debug.Log($"<-----> TryShowIntersitial: {value}");
            if (value)
            {
                showIntersitial();
            }

            return value;
        }

        /// <summary>
        /// rewardVideo Ad-->is Ready?
        /// </summary>
        public static bool IsRewardVideoReady()
        {
            var value = isReadyRewardVideo();
#if SHOW_IOS_ADSTATE_LOG
            Debug.Log("-----> isReadyRewardV:" + value);
#endif
            return value;
        }

        /// <summary>
        /// rewardVideo Ad-->show
        /// </summary>
        public static void ShowRewardVideo()
        {
            showRewardVideo();
        }

        /// <summary>
        /// rewardVideo Ad-->if Ready -->show，
        /// </summary>
        public static bool TryShowRewardVideo()
        {
            var value = isReadyRewardVideo();
            if (value)
            {
                showRewardVideo();
            }

            return value;
        }

        /// <summary>
        /// Banner->show
        /// </summary>
        public static void ShowBanner()
        {
            showBannerView();
        }

        /// <summary>
        /// Banner->remove
        /// </summary>
        public static void RemoveBanner()
        {
            removeBannerView();
        }
    }
}