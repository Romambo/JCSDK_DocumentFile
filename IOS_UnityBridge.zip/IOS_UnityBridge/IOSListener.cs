using System;

namespace IOSAd
{
    //---------------------------------------------------------------------
    //----------This file is the "IOS Listener" call and use file----------
    //---------------------------------------------------------------------

    public partial class IOSListener
    {
        /// <summary>
        /// splash Ad->Load Fail
        /// </summary>
        public static event Action OnSplashLoadFail;
        /// <summary>
        /// splash Ad->show
        /// </summary>
        public static event Action OnSplashShow;
        /// <summary>
        /// splash Ad->click
        /// </summary>
        public static event Action OnSplashClick;
        /// <summary>
        /// splash Ad->close
        /// </summary>
        public static event Action OnSplashClose;



        /// <summary>
        /// Banner->Load Fail
        /// </summary>
        public static event Action OnBannerLoadFail;
        /// <summary>
        /// Banner->show
        /// </summary>
        public static event Action OnBannerShow;
        /// <summary>
        /// Banner->click
        /// </summary>
        public static event Action OnBannerClick;
        /// <summary>
        /// Banner->clickclose
        /// </summary>
        public static event Action OnBannerTapClose;
        /// <summary>
        /// Banner->auto refresh
        /// parameters bool: Whether the refresh was successful
        /// </summary>
        public static event Action<bool> OnBannerAutoRefresh;



        /// <summary>
        /// intersitial Ad->Load Fail
        /// </summary>
        public static event Action OnIntersitialLoadFail;
        /// <summary>
        /// intersitial Ad->show
        /// parameters bool: Whether it shows success
        /// </summary>
        public static event Action<bool> OnIntersitialShow;
        /// <summary>
        /// intersitial Ad->click
        /// </summary>
        public static event Action OnIntersitialClick;
        /// <summary>
        /// intersitial Ad->close
        /// </summary>
        public static event Action OnIntersitialClose;
        /// <summary>
        /// intersitial Ad->PlayIngVideo Fail
        /// </summary>
        public static event Action OnIntersitialPlayVideoFail;
        /// <summary>
        /// intersitial Ad->PlayIngVideo  Start
        /// </summary>
        public static event Action OnIntersitialPlayVideoStart;
        /// <summary>
        /// intersitial Ad->PlayIngVideo  End
        /// </summary>
        public static event Action OnIntersitialPlayVideoEnd;



        /// <summary>
        /// rewardVideo Ad->Load Fail
        /// </summary>
        public static event Action OnRewardVedioLoadFail;
        ///// <summary>
        ///// rewardVideo Ad->show
        ///// parameters bool: Whether it shows success
        ///// </summary>
        //public static event Action<bool> OnRewardVedioShow;
        /// <summary>
        /// rewardVideo Ad->click
        /// </summary>
        public static event Action OnRewardVedioClick;
        /// <summary>
        /// rewardVideo Ad->close
        /// </summary>
        public static event Action OnRewardVedioClose;
        /// <summary>
        /// rewardVideo Ad->PlayIngVideo Fail
        /// </summary>
        public static event Action OnRewardVedioPlayVideoFail;
        /// <summary>
        /// rewardVideo Ad->PlayIngVideo  Start
        /// </summary>
        public static event Action OnRewardVedioPlayVideoStart;
        /// <summary>
        /// rewardVideo Ad->PlayIngVideo  End
        /// </summary>
        public static event Action OnRewardVedioPlayVideoEnd;
        /// <summary>
        /// rewardVideo Ad->获得奖励/gain an award
        /// </summary>
        public static event Action OnRewardVedioSuccess;
    }
}